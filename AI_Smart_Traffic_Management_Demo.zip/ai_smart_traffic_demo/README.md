# AI Smart Traffic Management System — Demo

A beginner-friendly advanced-project demo for BCA AI & ML.

## Features
- Real-time/simulated traffic dashboard
- Vehicle counting by class
- Traffic-density calculation
- Congestion level
- Adaptive signal timing
- Historical metrics chart
- Optional YOLO video detection
- CSV export

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the Streamlit URL shown in the terminal.

## YOLO mode
Place a YOLO model such as `yolo11n.pt` or `yolov8n.pt` in this folder.
Then upload an MP4 video from the sidebar.

Without a model/video, the app runs in Demo Simulation mode, so you can demonstrate the complete dashboard.

## Project flow
Camera/Video -> Object Detection -> Vehicle Count -> Traffic Density -> Congestion Prediction -> Signal Timing -> Dashboard
