import time
import random
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="AI Smart Traffic Management", page_icon="🚦", layout="wide")

VEHICLES = ["car", "motorcycle", "bus", "truck"]

def density_score(counts):
    # Demo formula; replace with calibrated road-capacity values for a real deployment.
    weighted = (
        counts.get("car", 0)
        + counts.get("motorcycle", 0)
        + 2 * counts.get("bus", 0)
        + 2 * counts.get("truck", 0)
    )
    return min(100, weighted * 2)

def congestion(score):
    if score < 30:
        return "LOW", "🟢"
    if score < 65:
        return "MEDIUM", "🟡"
    return "HIGH", "🔴"

def signal_time(score):
    # Demo adaptive timing logic.
    return int(np.clip(25 + score * 0.65, 25, 90))

def demo_counts():
    return {
        "car": random.randint(8, 35),
        "motorcycle": random.randint(5, 25),
        "bus": random.randint(1, 6),
        "truck": random.randint(1, 8),
    }

def yolo_counts(frame, model):
    results = model(frame, verbose=False)
    counts = {v: 0 for v in VEHICLES}
    annotated = frame.copy()

    # COCO class IDs: car=2, motorcycle=3, bus=5, truck=7
    ids = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}

    for result in results:
        if result.boxes is None:
            continue
        for box in result.boxes:
            cls_id = int(box.cls[0])
            if cls_id in ids:
                counts[ids[cls_id]] += 1

        annotated = result.plot()

    return counts, annotated

st.title("🚦 AI Smart Traffic Management System")
st.caption("BCA AI & ML Demo Project — Vehicle Detection + Traffic Analytics + Adaptive Signal")

with st.sidebar:
    st.header("⚙️ Demo Controls")
    mode = st.radio("Detection mode", ["Demo Simulation", "YOLO Video"])
    auto_refresh = st.checkbox("Auto refresh", value=False)
    refresh_seconds = st.slider("Refresh interval (seconds)", 1, 10, 3)

    uploaded = None
    model = None

    if mode == "YOLO Video":
        uploaded = st.file_uploader("Upload traffic video (MP4/AVI)", type=["mp4", "avi", "mov"])
        model_path = st.text_input("YOLO model path", "yolo11n.pt")
        if uploaded:
            try:
                from ultralytics import YOLO
                model = YOLO(model_path)
            except Exception as e:
                st.error(f"Could not load YOLO model: {e}")

if "history" not in st.session_state:
    st.session_state.history = []

frame_placeholder = st.empty()

if mode == "YOLO Video" and uploaded and model:
    video_bytes = uploaded.read()
    temp_path = "/tmp/traffic_demo.mp4"
    with open(temp_path, "wb") as f:
        f.write(video_bytes)

    cap = cv2.VideoCapture(temp_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    step = max(1, int(fps // 2))

    frame_no = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break

        frame_no += 1
        if frame_no % step != 0:
            continue

        counts, annotated = yolo_counts(frame, model)
        score = density_score(counts)
        level, icon = congestion(score)
        green = signal_time(score)

        st.session_state.history.append({
            "time": datetime.now().strftime("%H:%M:%S"),
            "density": score,
            "cars": counts["car"],
            "motorcycles": counts["motorcycle"],
            "buses": counts["bus"],
            "trucks": counts["truck"],
        })

        frame_placeholder.image(cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB), caption=f"Frame {frame_no}/{total_frames}")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("🚗 Cars", counts["car"])
        c2.metric("🏍️ Motorcycles", counts["motorcycle"])
        c3.metric("🚌 Buses", counts["bus"])
        c4.metric("🚛 Trucks", counts["truck"])

        a, b, c = st.columns(3)
        a.metric("Traffic Density", f"{score:.0f}%")
        b.metric("Congestion", f"{icon} {level}")
        c.metric("Suggested Green Time", f"{green} sec")

        if auto_refresh:
            time.sleep(refresh_seconds)

    cap.release()

else:
    counts = demo_counts()
    score = density_score(counts)
    level, icon = congestion(score)
    green = signal_time(score)

    st.session_state.history.append({
        "time": datetime.now().strftime("%H:%M:%S"),
        "density": score,
        "cars": counts["car"],
        "motorcycles": counts["motorcycle"],
        "buses": counts["bus"],
        "trucks": counts["truck"],
    })

    st.subheader("📡 Live Junction Status")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("🚗 Cars", counts["car"])
    c2.metric("🏍️ Motorcycles", counts["motorcycle"])
    c3.metric("🚌 Buses", counts["bus"])
    c4.metric("🚛 Trucks", counts["truck"])

    a, b, c = st.columns(3)
    a.metric("Traffic Density", f"{score:.0f}%")
    b.metric("Congestion", f"{icon} {level}")
    c.metric("Suggested Green Time", f"{green} sec")

    st.info("Demo Simulation is active. Use YOLO Video mode to process an actual traffic video.")

st.divider()

st.subheader("📊 Traffic Analytics")
hist = pd.DataFrame(st.session_state.history[-30:])

if not hist.empty:
    st.line_chart(hist.set_index("time")[["density"]])
    st.bar_chart(hist.set_index("time")[["cars", "motorcycles", "buses", "trucks"]])

    csv = hist.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Traffic Report CSV", csv, "traffic_report.csv", "text/csv")

st.divider()

st.subheader("🧠 AI Decision Logic")
st.code("""Vehicle Detection
       ↓
Vehicle Count
       ↓
Weighted Traffic Density
       ↓
Congestion Level
       ↓
Adaptive Green Signal Time
       ↓
Traffic Dashboard""")

st.caption("Educational demo only. Signal timing should not be deployed on public roads without calibrated traffic-engineering validation and appropriate safety controls.")
