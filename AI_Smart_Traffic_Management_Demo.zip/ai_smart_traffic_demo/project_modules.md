# Modules

## 1. Video Input
Accept CCTV/video frames.

## 2. Object Detection
YOLO identifies road vehicles.

## 3. Vehicle Counting
Counts cars, motorcycles, buses and trucks.

## 4. Traffic Density
A weighted score estimates how busy the junction is.

## 5. Congestion Classification
LOW / MEDIUM / HIGH.

## 6. Adaptive Signal
The demo converts density into a suggested green-light duration.

## 7. Dashboard
Streamlit displays live metrics and historical charts.

## 8. Future Prediction
Train a time-series model such as XGBoost/LSTM on historical traffic counts to predict future congestion.
